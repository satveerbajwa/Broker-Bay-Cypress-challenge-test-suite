+/// <reference types="cypress" />

it('verify the text and output',function() {
    
    cy.visit('http://localhost:3000/');
    cy.get('h1').should('have.text', 'Enter a number to get the median of primes:');
    cy.get('input').type('5');
    cy.get('button').click();
    cy.get('h2').should('have.text', 'The median is: [2,3]'); 
})

it('verify when input is 0',function() {
   
    cy.visit('http://localhost:3000/');
    cy.get('input').type('0');
    cy.get('button').click();
    cy.get('h2').should('have.text', 'The median is: [,]'); 
})
it('Verify when no input and  the spinner element is present ',function() {

   cy.visit('http://localhost:3000/');
   cy.get('button').click();
   cy.get('.fa').should('be.visible');
   //prevent failing the test from uncaught expection
   Cypress.on('uncaught:exception', (err, runnable) => {
    // returning false here prevents Cypress from
    // failing the test
    return false
})
})
it('Verify when trying to add char in text box ',function() {

    cy.visit('http://localhost:3000/');
    cy.get('input').type('xyz');
    cy.get('input').should('have.value', '');
})

it('Verify when trying to add special char in text box ',function() {

    cy.visit('http://localhost:3000/');
    cy.get('input').type('#$%');
    cy.get('input').should('have.value', '');
})

it('enter random number ',function() {

    cy.visit('http://localhost:3000/');
    cy.get('input').type('46376473467367436746736476767');
    cy.get('input').should('have.value', '46376473467367436746736476767');

})

it('enter negative number ',function() {

    cy.visit('http://localhost:3000/');
    cy.get('input').type('-45');
    cy.get('input').should('have.value', '-45');

})



